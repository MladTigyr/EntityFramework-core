﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-B752TI8\SQLEXPRESS;Database=Medicines;Integrated Security=True";
    }
}
