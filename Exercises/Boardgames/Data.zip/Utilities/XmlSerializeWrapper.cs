﻿namespace Boardgames.Utilities
{
    using System.Xml.Serialization;

    public static class XmlSerializeWrapper
    {
        public static T? Deserialize<T>(string xmlInput, string rootName)
        {
            XmlRootAttribute rootAttribute = new XmlRootAttribute(rootName);
            
            XmlSerializer serializer = new XmlSerializer(typeof(T), rootAttribute);

            using StringReader stringReader = new StringReader(xmlInput);

            T? dtos = (T?)serializer.Deserialize(stringReader);

            return dtos;
        }
    }
}
