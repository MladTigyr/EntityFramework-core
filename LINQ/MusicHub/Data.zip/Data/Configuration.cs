﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-B752TI8\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True";
    }
}
