﻿using System.Xml.Serialization;

namespace CarDealer.DTOs.Export.ExportCarsWithParts
{
    [XmlType("part")]
    public class ExportPartCarDetailDto
    {
        [XmlAttribute("name")]
        public string Name { get; set; } = null!;

        [XmlAttribute("price")]
        public decimal Price { get; set; }
    }
}