﻿using System.Diagnostics.Contracts;
using System.Xml.Serialization;

namespace ProductShop.DTOs.Export.ExportCategoriesByProductsCount
{
    [XmlType("Category")]
    public class ExportCategoryDetailsDto
    {
        [XmlElement("name")]
        public string Name { get; set; } = null!;

        [XmlElement("count")]
        public int Count { get; set; }

        [XmlElement("averagePrice")]
        public decimal AveragePrice { get; set; }

        [XmlElement("totalRevenue")]
        public decimal TotalRevenue { get; set; }
    }
}