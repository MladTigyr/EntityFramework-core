﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-B752TI8\SQLEXPRESS;Database=ProductShop;Integrated Security=True;Encrypt=False";
    }
}
